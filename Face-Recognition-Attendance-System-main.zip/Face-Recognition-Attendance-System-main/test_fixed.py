
# ... Your original imports and code remain unchanged before this

# Only showing the modified part (you will copy and merge it into your full script if needed)

def enter_data_DB():
    global cursor  # Fix: Declare cursor as global
    ENROLLMENT = ENR_ENTRY.get()
    STUDENT = STUDENT_ENTRY.get()
    if ENROLLMENT == '' or STUDENT == '':
        err_screen1()
    else:
        time = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
        Insert_data = "INSERT INTO " + DB_table_name +             " (ID,ENROLLMENT,NAME,DATE,TIME) VALUES (0, %s, %s, %s,%s)"
        VALUES = (str(ENROLLMENT), str(STUDENT), str(Date), str(time))
        try:
            cursor.execute(Insert_data, VALUES)
        except Exception as e:
            print(e)
        ENR_ENTRY.delete(first=0, last=22)
        STUDENT_ENTRY.delete(first=0, last=22)

def create_csv():
    global cursor  # Fix: Declare cursor as global
    cursor.execute("SELECT * FROM " + DB_table_name + ";")
    csv_name = 'Attendance/' + DB_table_name + '.csv'
    with open(csv_name, "w", newline="") as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow([i[0] for i in cursor.description])  # headers
        csv_writer.writerows(cursor)
        print("CSV created successfully at:", csv_name)
